package com.example.demo.controller;

import java.net.URI;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Component
public class OrderImpl {
	
	@Autowired
	private RestTemplate restTemplate;

	@HystrixCommand(fallbackMethod = "ofssmymethod")
	public ResponseEntity<String> getName() {
		try {
			System.out.println("*********************Inside URI ...*******************");
			URI endPoint = URI.create("http://localhost:9090/visitors");
			return restTemplate.getForEntity(endPoint, String.class);
		} catch (Exception e) {
			throw new RuntimeException();
		}
	}

	//falback method in case it the service is avialable.
	public ResponseEntity<String> ofssmymethod() {
		System.out.println("*********************Micoservice is not available*******************");
		return new ResponseEntity<String>("Visitor Microservice is not available",HttpStatus.CONFLICT);

	}



	
	@HystrixCommand(fallbackMethod = "reviewMethodDown")
	public ResponseEntity<String> getReview(String pName) {
		try {
			System.out.println("*********************Inside URI ...*******************");
			URI endPoint = URI.create("http://localhost:9090/visitors/reviews/"+pName);
			return restTemplate.getForEntity(endPoint, String.class);
		} catch (Exception e) {
			throw new RuntimeException();
		}

	}
	
	//fallback method in case it the service is available.
	public ResponseEntity<String> reviewMethodDown(String pName) {
		System.out.println("*********************Micoservice is not available*******************");
		return new ResponseEntity<String>(pName+ " :: Review Microservice is not available",HttpStatus.CONFLICT);

	}
	
	public ResponseEntity<String> getCustomer() {
		try {
			System.out.println("*********************Inside URI ...*******************");
			URI endPoint = URI.create("http://localhost:9090/customer/9191");
			return restTemplate.getForEntity(endPoint, String.class);
		} catch (Exception e) {
			throw new RuntimeException();
		}

	}
	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}















