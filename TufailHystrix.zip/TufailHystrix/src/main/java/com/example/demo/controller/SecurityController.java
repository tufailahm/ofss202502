package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SecurityController {

	@Autowired
	private OrderImpl orderImpl;

	ResponseEntity<String> exchange = null;

	@RequestMapping("/visitor") // http://localhost:6050/visitor
	public String getVisitorsDetails() {

		try {
			exchange = orderImpl.getName();
			return exchange.getBody() + "::status code :" + exchange.getStatusCodeValue();
		} catch (Exception e) {

		}
		return null;

	}
		
	@GetMapping("/hh")
	public ResponseEntity<String> getHH()
	{
		return orderImpl.getCustomer();
	}

	
	@GetMapping("/reviews/{productName}")		//http://localhost:6050/reviews/Pendrive
	public ResponseEntity<String> getReview(@PathVariable("productName")String productName)
	{
		return orderImpl.getReview(productName);
	}
	
}
