
drop table trandetails;

drop table loan;

drop table account;

drop table branch;

drop table customer;